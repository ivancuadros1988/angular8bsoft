export class Transaccion {
    constructor(
    public codigo: string,
    public descripcion: string
    ) {}
    }
    